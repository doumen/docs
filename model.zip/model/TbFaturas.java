/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbFaturas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbFaturas.findAll", query = "SELECT t FROM TbFaturas t"),
    @NamedQuery(name = "TbFaturas.findById", query = "SELECT t FROM TbFaturas t WHERE t.id = :id"),
    @NamedQuery(name = "TbFaturas.findByVencimento", query = "SELECT t FROM TbFaturas t WHERE t.vencimento = :vencimento"),
    @NamedQuery(name = "TbFaturas.findByNumero", query = "SELECT t FROM TbFaturas t WHERE t.numero = :numero"),
    @NamedQuery(name = "TbFaturas.findByValor", query = "SELECT t FROM TbFaturas t WHERE t.valor = :valor"),
    @NamedQuery(name = "TbFaturas.findByEmissaoDocumento", query = "SELECT t FROM TbFaturas t WHERE t.emissaoDocumento = :emissaoDocumento"),
    @NamedQuery(name = "TbFaturas.findByNumeroNFe", query = "SELECT t FROM TbFaturas t WHERE t.numeroNFe = :numeroNFe"),
    @NamedQuery(name = "TbFaturas.findBySerie", query = "SELECT t FROM TbFaturas t WHERE t.serie = :serie"),
    @NamedQuery(name = "TbFaturas.findByEmitenteCnpj", query = "SELECT t FROM TbFaturas t WHERE t.emitenteCnpj = :emitenteCnpj"),
    @NamedQuery(name = "TbFaturas.findByEmitenteRazaoSocial", query = "SELECT t FROM TbFaturas t WHERE t.emitenteRazaoSocial = :emitenteRazaoSocial"),
    @NamedQuery(name = "TbFaturas.findByValorTotalNFe", query = "SELECT t FROM TbFaturas t WHERE t.valorTotalNFe = :valorTotalNFe"),
    @NamedQuery(name = "TbFaturas.findByDataInclusao", query = "SELECT t FROM TbFaturas t WHERE t.dataInclusao = :dataInclusao")})
public class TbFaturas implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Vencimento")
    @Temporal(TemporalType.DATE)
    private Date vencimento;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "Numero")
    private String numero;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "Valor")
    private BigDecimal valor;
    @Basic(optional = false)
    @NotNull
    @Column(name = "EmissaoDocumento")
    @Temporal(TemporalType.TIMESTAMP)
    private Date emissaoDocumento;
    @Basic(optional = false)
    @NotNull
    @Column(name = "NumeroNFe")
    private int numeroNFe;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Serie")
    private int serie;
    @Basic(optional = false)
    @NotNull
    @Column(name = "EmitenteCnpj")
    private int emitenteCnpj;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "EmitenteRazaoSocial")
    private String emitenteRazaoSocial;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ValorTotalNFe")
    private BigDecimal valorTotalNFe;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbFaturasId")
    private Collection<TbFaturasDependencias> tbFaturasDependenciasCollection;

    public TbFaturas() {
    }

    public TbFaturas(Integer id) {
        this.id = id;
    }

    public TbFaturas(Integer id, Date vencimento, String numero, BigDecimal valor, Date emissaoDocumento, int numeroNFe, int serie, int emitenteCnpj, String emitenteRazaoSocial, BigDecimal valorTotalNFe, Date dataInclusao) {
        this.id = id;
        this.vencimento = vencimento;
        this.numero = numero;
        this.valor = valor;
        this.emissaoDocumento = emissaoDocumento;
        this.numeroNFe = numeroNFe;
        this.serie = serie;
        this.emitenteCnpj = emitenteCnpj;
        this.emitenteRazaoSocial = emitenteRazaoSocial;
        this.valorTotalNFe = valorTotalNFe;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getVencimento() {
        return vencimento;
    }

    public void setVencimento(Date vencimento) {
        this.vencimento = vencimento;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public Date getEmissaoDocumento() {
        return emissaoDocumento;
    }

    public void setEmissaoDocumento(Date emissaoDocumento) {
        this.emissaoDocumento = emissaoDocumento;
    }

    public int getNumeroNFe() {
        return numeroNFe;
    }

    public void setNumeroNFe(int numeroNFe) {
        this.numeroNFe = numeroNFe;
    }

    public int getSerie() {
        return serie;
    }

    public void setSerie(int serie) {
        this.serie = serie;
    }

    public int getEmitenteCnpj() {
        return emitenteCnpj;
    }

    public void setEmitenteCnpj(int emitenteCnpj) {
        this.emitenteCnpj = emitenteCnpj;
    }

    public String getEmitenteRazaoSocial() {
        return emitenteRazaoSocial;
    }

    public void setEmitenteRazaoSocial(String emitenteRazaoSocial) {
        this.emitenteRazaoSocial = emitenteRazaoSocial;
    }

    public BigDecimal getValorTotalNFe() {
        return valorTotalNFe;
    }

    public void setValorTotalNFe(BigDecimal valorTotalNFe) {
        this.valorTotalNFe = valorTotalNFe;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    @XmlTransient
    public Collection<TbFaturasDependencias> getTbFaturasDependenciasCollection() {
        return tbFaturasDependenciasCollection;
    }

    public void setTbFaturasDependenciasCollection(Collection<TbFaturasDependencias> tbFaturasDependenciasCollection) {
        this.tbFaturasDependenciasCollection = tbFaturasDependenciasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbFaturas)) {
            return false;
        }
        TbFaturas other = (TbFaturas) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbFaturas[ id=" + id + " ]";
    }
    
}
