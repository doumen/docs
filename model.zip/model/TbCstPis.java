/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbCstPis")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbCstPis.findAll", query = "SELECT t FROM TbCstPis t"),
    @NamedQuery(name = "TbCstPis.findById", query = "SELECT t FROM TbCstPis t WHERE t.id = :id"),
    @NamedQuery(name = "TbCstPis.findByCst", query = "SELECT t FROM TbCstPis t WHERE t.cst = :cst"),
    @NamedQuery(name = "TbCstPis.findByDescricao", query = "SELECT t FROM TbCstPis t WHERE t.descricao = :descricao"),
    @NamedQuery(name = "TbCstPis.findByDataInclusao", query = "SELECT t FROM TbCstPis t WHERE t.dataInclusao = :dataInclusao")})
public class TbCstPis implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Cst")
    private int cst;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 120)
    @Column(name = "Descricao")
    private String descricao;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbCstPisId")
    private Collection<TbPisDependencias> tbPisDependenciasCollection;

    public TbCstPis() {
    }

    public TbCstPis(Integer id) {
        this.id = id;
    }

    public TbCstPis(Integer id, int cst, String descricao, Date dataInclusao) {
        this.id = id;
        this.cst = cst;
        this.descricao = descricao;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getCst() {
        return cst;
    }

    public void setCst(int cst) {
        this.cst = cst;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    @XmlTransient
    public Collection<TbPisDependencias> getTbPisDependenciasCollection() {
        return tbPisDependenciasCollection;
    }

    public void setTbPisDependenciasCollection(Collection<TbPisDependencias> tbPisDependenciasCollection) {
        this.tbPisDependenciasCollection = tbPisDependenciasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbCstPis)) {
            return false;
        }
        TbCstPis other = (TbCstPis) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbCstPis[ id=" + id + " ]";
    }
    
}
