/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbAssinantes_tbSpedSocial")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbAssinantestbSpedSocial.findAll", query = "SELECT t FROM TbAssinantestbSpedSocial t"),
    @NamedQuery(name = "TbAssinantestbSpedSocial.findById", query = "SELECT t FROM TbAssinantestbSpedSocial t WHERE t.id = :id"),
    @NamedQuery(name = "TbAssinantestbSpedSocial.findByDataInclusao", query = "SELECT t FROM TbAssinantestbSpedSocial t WHERE t.dataInclusao = :dataInclusao")})
public class TbAssinantestbSpedSocial implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @JoinColumn(name = "tbAssinantes_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbAssinantes tbAssinantesId;
    @JoinColumn(name = "tbSpedSocial_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbSpedSocial tbSpedSocialId;
    @JoinColumn(name = "tbSpedSocialArquivos_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbSpedSocialArquivos tbSpedSocialArquivosId;
    @JoinColumn(name = "tbSpedSocialConfiguracoes_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbSpedSocialConfiguracoes tbSpedSocialConfiguracoesId;

    public TbAssinantestbSpedSocial() {
    }

    public TbAssinantestbSpedSocial(Integer id) {
        this.id = id;
    }

    public TbAssinantestbSpedSocial(Integer id, Date dataInclusao) {
        this.id = id;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public TbAssinantes getTbAssinantesId() {
        return tbAssinantesId;
    }

    public void setTbAssinantesId(TbAssinantes tbAssinantesId) {
        this.tbAssinantesId = tbAssinantesId;
    }

    public TbSpedSocial getTbSpedSocialId() {
        return tbSpedSocialId;
    }

    public void setTbSpedSocialId(TbSpedSocial tbSpedSocialId) {
        this.tbSpedSocialId = tbSpedSocialId;
    }

    public TbSpedSocialArquivos getTbSpedSocialArquivosId() {
        return tbSpedSocialArquivosId;
    }

    public void setTbSpedSocialArquivosId(TbSpedSocialArquivos tbSpedSocialArquivosId) {
        this.tbSpedSocialArquivosId = tbSpedSocialArquivosId;
    }

    public TbSpedSocialConfiguracoes getTbSpedSocialConfiguracoesId() {
        return tbSpedSocialConfiguracoesId;
    }

    public void setTbSpedSocialConfiguracoesId(TbSpedSocialConfiguracoes tbSpedSocialConfiguracoesId) {
        this.tbSpedSocialConfiguracoesId = tbSpedSocialConfiguracoesId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbAssinantestbSpedSocial)) {
            return false;
        }
        TbAssinantestbSpedSocial other = (TbAssinantestbSpedSocial) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbAssinantestbSpedSocial[ id=" + id + " ]";
    }
    
}
