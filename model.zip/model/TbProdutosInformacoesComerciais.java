/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbProdutosInformacoesComerciais")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbProdutosInformacoesComerciais.findAll", query = "SELECT t FROM TbProdutosInformacoesComerciais t"),
    @NamedQuery(name = "TbProdutosInformacoesComerciais.findById", query = "SELECT t FROM TbProdutosInformacoesComerciais t WHERE t.id = :id"),
    @NamedQuery(name = "TbProdutosInformacoesComerciais.findByQuantidade", query = "SELECT t FROM TbProdutosInformacoesComerciais t WHERE t.quantidade = :quantidade"),
    @NamedQuery(name = "TbProdutosInformacoesComerciais.findByUnidadeMedidaComercial", query = "SELECT t FROM TbProdutosInformacoesComerciais t WHERE t.unidadeMedidaComercial = :unidadeMedidaComercial"),
    @NamedQuery(name = "TbProdutosInformacoesComerciais.findByValorUnitario", query = "SELECT t FROM TbProdutosInformacoesComerciais t WHERE t.valorUnitario = :valorUnitario"),
    @NamedQuery(name = "TbProdutosInformacoesComerciais.findByValorTotal", query = "SELECT t FROM TbProdutosInformacoesComerciais t WHERE t.valorTotal = :valorTotal"),
    @NamedQuery(name = "TbProdutosInformacoesComerciais.findByDataInclusao", query = "SELECT t FROM TbProdutosInformacoesComerciais t WHERE t.dataInclusao = :dataInclusao")})
public class TbProdutosInformacoesComerciais implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "Quantidade")
    private BigDecimal quantidade;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "UnidadeMedidaComercial")
    private String unidadeMedidaComercial;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ValorUnitario")
    private BigDecimal valorUnitario;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ValorTotal")
    private BigDecimal valorTotal;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbProdutosInformacoesComerciaisId")
    private Collection<TbProdutosDependencias> tbProdutosDependenciasCollection;

    public TbProdutosInformacoesComerciais() {
    }

    public TbProdutosInformacoesComerciais(Integer id) {
        this.id = id;
    }

    public TbProdutosInformacoesComerciais(Integer id, BigDecimal quantidade, String unidadeMedidaComercial, BigDecimal valorUnitario, BigDecimal valorTotal, Date dataInclusao) {
        this.id = id;
        this.quantidade = quantidade;
        this.unidadeMedidaComercial = unidadeMedidaComercial;
        this.valorUnitario = valorUnitario;
        this.valorTotal = valorTotal;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BigDecimal getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(BigDecimal quantidade) {
        this.quantidade = quantidade;
    }

    public String getUnidadeMedidaComercial() {
        return unidadeMedidaComercial;
    }

    public void setUnidadeMedidaComercial(String unidadeMedidaComercial) {
        this.unidadeMedidaComercial = unidadeMedidaComercial;
    }

    public BigDecimal getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(BigDecimal valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(BigDecimal valorTotal) {
        this.valorTotal = valorTotal;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    @XmlTransient
    public Collection<TbProdutosDependencias> getTbProdutosDependenciasCollection() {
        return tbProdutosDependenciasCollection;
    }

    public void setTbProdutosDependenciasCollection(Collection<TbProdutosDependencias> tbProdutosDependenciasCollection) {
        this.tbProdutosDependenciasCollection = tbProdutosDependenciasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbProdutosInformacoesComerciais)) {
            return false;
        }
        TbProdutosInformacoesComerciais other = (TbProdutosInformacoesComerciais) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbProdutosInformacoesComerciais[ id=" + id + " ]";
    }
    
}
