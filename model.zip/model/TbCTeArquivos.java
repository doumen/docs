/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbCTeArquivos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbCTeArquivos.findAll", query = "SELECT t FROM TbCTeArquivos t"),
    @NamedQuery(name = "TbCTeArquivos.findById", query = "SELECT t FROM TbCTeArquivos t WHERE t.id = :id"),
    @NamedQuery(name = "TbCTeArquivos.findByDataInclusao", query = "SELECT t FROM TbCTeArquivos t WHERE t.dataInclusao = :dataInclusao")})
public class TbCTeArquivos implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "ArquivoCTeXML")
    private byte[] arquivoCTeXML;
    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "ArquivoDactePDF")
    private byte[] arquivoDactePDF;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbCTeArquivosId")
    private Collection<TbCTetbNFe> tbCTetbNFeCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbCTeArquivosId")
    private Collection<TbAssinantestbCTe> tbAssinantestbCTeCollection;

    public TbCTeArquivos() {
    }

    public TbCTeArquivos(Integer id) {
        this.id = id;
    }

    public TbCTeArquivos(Integer id, byte[] arquivoCTeXML, byte[] arquivoDactePDF, Date dataInclusao) {
        this.id = id;
        this.arquivoCTeXML = arquivoCTeXML;
        this.arquivoDactePDF = arquivoDactePDF;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public byte[] getArquivoCTeXML() {
        return arquivoCTeXML;
    }

    public void setArquivoCTeXML(byte[] arquivoCTeXML) {
        this.arquivoCTeXML = arquivoCTeXML;
    }

    public byte[] getArquivoDactePDF() {
        return arquivoDactePDF;
    }

    public void setArquivoDactePDF(byte[] arquivoDactePDF) {
        this.arquivoDactePDF = arquivoDactePDF;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    @XmlTransient
    public Collection<TbCTetbNFe> getTbCTetbNFeCollection() {
        return tbCTetbNFeCollection;
    }

    public void setTbCTetbNFeCollection(Collection<TbCTetbNFe> tbCTetbNFeCollection) {
        this.tbCTetbNFeCollection = tbCTetbNFeCollection;
    }

    @XmlTransient
    public Collection<TbAssinantestbCTe> getTbAssinantestbCTeCollection() {
        return tbAssinantestbCTeCollection;
    }

    public void setTbAssinantestbCTeCollection(Collection<TbAssinantestbCTe> tbAssinantestbCTeCollection) {
        this.tbAssinantestbCTeCollection = tbAssinantestbCTeCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbCTeArquivos)) {
            return false;
        }
        TbCTeArquivos other = (TbCTeArquivos) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbCTeArquivos[ id=" + id + " ]";
    }
    
}
