/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbUsuarios")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbUsuarios.findAll", query = "SELECT t FROM TbUsuarios t"),
    @NamedQuery(name = "TbUsuarios.findById", query = "SELECT t FROM TbUsuarios t WHERE t.id = :id"),
    @NamedQuery(name = "TbUsuarios.findByUsuario", query = "SELECT t FROM TbUsuarios t WHERE t.usuario = :usuario"),
    @NamedQuery(name = "TbUsuarios.findBySenha", query = "SELECT t FROM TbUsuarios t WHERE t.senha = :senha"),
    @NamedQuery(name = "TbUsuarios.findByPermissaoAreaUsuario", query = "SELECT t FROM TbUsuarios t WHERE t.permissaoAreaUsuario = :permissaoAreaUsuario"),
    @NamedQuery(name = "TbUsuarios.findByPermissaoAreaContador", query = "SELECT t FROM TbUsuarios t WHERE t.permissaoAreaContador = :permissaoAreaContador"),
    @NamedQuery(name = "TbUsuarios.findByPermissaoAreaAdministrador", query = "SELECT t FROM TbUsuarios t WHERE t.permissaoAreaAdministrador = :permissaoAreaAdministrador"),
    @NamedQuery(name = "TbUsuarios.findByDataInclusao", query = "SELECT t FROM TbUsuarios t WHERE t.dataInclusao = :dataInclusao")})
public class TbUsuarios implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "Usuario")
    private String usuario;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "Senha")
    private String senha;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PermissaoAreaUsuario")
    private boolean permissaoAreaUsuario;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PermissaoAreaContador")
    private boolean permissaoAreaContador;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PermissaoAreaAdministrador")
    private boolean permissaoAreaAdministrador;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbUsuariosId")
    private Collection<TbAssinantestbUsuarios> tbAssinantestbUsuariosCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbUsuariosId")
    private Collection<TbContabilidadetbUsuarios> tbContabilidadetbUsuariosCollection;

    public TbUsuarios() {
    }

    public TbUsuarios(Integer id) {
        this.id = id;
    }

    public TbUsuarios(Integer id, String usuario, String senha, boolean permissaoAreaUsuario, boolean permissaoAreaContador, boolean permissaoAreaAdministrador, Date dataInclusao) {
        this.id = id;
        this.usuario = usuario;
        this.senha = senha;
        this.permissaoAreaUsuario = permissaoAreaUsuario;
        this.permissaoAreaContador = permissaoAreaContador;
        this.permissaoAreaAdministrador = permissaoAreaAdministrador;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public boolean getPermissaoAreaUsuario() {
        return permissaoAreaUsuario;
    }

    public void setPermissaoAreaUsuario(boolean permissaoAreaUsuario) {
        this.permissaoAreaUsuario = permissaoAreaUsuario;
    }

    public boolean getPermissaoAreaContador() {
        return permissaoAreaContador;
    }

    public void setPermissaoAreaContador(boolean permissaoAreaContador) {
        this.permissaoAreaContador = permissaoAreaContador;
    }

    public boolean getPermissaoAreaAdministrador() {
        return permissaoAreaAdministrador;
    }

    public void setPermissaoAreaAdministrador(boolean permissaoAreaAdministrador) {
        this.permissaoAreaAdministrador = permissaoAreaAdministrador;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    @XmlTransient
    public Collection<TbAssinantestbUsuarios> getTbAssinantestbUsuariosCollection() {
        return tbAssinantestbUsuariosCollection;
    }

    public void setTbAssinantestbUsuariosCollection(Collection<TbAssinantestbUsuarios> tbAssinantestbUsuariosCollection) {
        this.tbAssinantestbUsuariosCollection = tbAssinantestbUsuariosCollection;
    }

    @XmlTransient
    public Collection<TbContabilidadetbUsuarios> getTbContabilidadetbUsuariosCollection() {
        return tbContabilidadetbUsuariosCollection;
    }

    public void setTbContabilidadetbUsuariosCollection(Collection<TbContabilidadetbUsuarios> tbContabilidadetbUsuariosCollection) {
        this.tbContabilidadetbUsuariosCollection = tbContabilidadetbUsuariosCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbUsuarios)) {
            return false;
        }
        TbUsuarios other = (TbUsuarios) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbUsuarios[ id=" + id + " ]";
    }
    
}
