/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbContabilidade")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbContabilidade.findAll", query = "SELECT t FROM TbContabilidade t"),
    @NamedQuery(name = "TbContabilidade.findById", query = "SELECT t FROM TbContabilidade t WHERE t.id = :id"),
    @NamedQuery(name = "TbContabilidade.findByCnpj", query = "SELECT t FROM TbContabilidade t WHERE t.cnpj = :cnpj"),
    @NamedQuery(name = "TbContabilidade.findByInscricaoEstadual", query = "SELECT t FROM TbContabilidade t WHERE t.inscricaoEstadual = :inscricaoEstadual"),
    @NamedQuery(name = "TbContabilidade.findByNomeFantasia", query = "SELECT t FROM TbContabilidade t WHERE t.nomeFantasia = :nomeFantasia"),
    @NamedQuery(name = "TbContabilidade.findByRazaoSocial", query = "SELECT t FROM TbContabilidade t WHERE t.razaoSocial = :razaoSocial"),
    @NamedQuery(name = "TbContabilidade.findByEndereco", query = "SELECT t FROM TbContabilidade t WHERE t.endereco = :endereco"),
    @NamedQuery(name = "TbContabilidade.findByEnderecoNumero", query = "SELECT t FROM TbContabilidade t WHERE t.enderecoNumero = :enderecoNumero"),
    @NamedQuery(name = "TbContabilidade.findByEnderecoComplemento", query = "SELECT t FROM TbContabilidade t WHERE t.enderecoComplemento = :enderecoComplemento"),
    @NamedQuery(name = "TbContabilidade.findByBairro", query = "SELECT t FROM TbContabilidade t WHERE t.bairro = :bairro"),
    @NamedQuery(name = "TbContabilidade.findByMunicipio", query = "SELECT t FROM TbContabilidade t WHERE t.municipio = :municipio"),
    @NamedQuery(name = "TbContabilidade.findByUf", query = "SELECT t FROM TbContabilidade t WHERE t.uf = :uf"),
    @NamedQuery(name = "TbContabilidade.findByCep", query = "SELECT t FROM TbContabilidade t WHERE t.cep = :cep"),
    @NamedQuery(name = "TbContabilidade.findByComissao", query = "SELECT t FROM TbContabilidade t WHERE t.comissao = :comissao"),
    @NamedQuery(name = "TbContabilidade.findByDataInclusao", query = "SELECT t FROM TbContabilidade t WHERE t.dataInclusao = :dataInclusao")})
public class TbContabilidade implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Cnpj")
    private int cnpj;
    @Size(max = 14)
    @Column(name = "InscricaoEstadual")
    private String inscricaoEstadual;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "NomeFantasia")
    private String nomeFantasia;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "RazaoSocial")
    private String razaoSocial;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "Endereco")
    private String endereco;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 8)
    @Column(name = "EnderecoNumero")
    private String enderecoNumero;
    @Size(max = 60)
    @Column(name = "EnderecoComplemento")
    private String enderecoComplemento;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Bairro")
    private String bairro;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Municipio")
    private String municipio;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "Uf")
    private String uf;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Cep")
    private int cep;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "Comissao")
    private BigDecimal comissao;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbContabilidadeId")
    private Collection<TbContabilidadetbUsuarios> tbContabilidadetbUsuariosCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbContabilidadeId")
    private Collection<TbAssinantestbContabilidade> tbAssinantestbContabilidadeCollection;

    public TbContabilidade() {
    }

    public TbContabilidade(Integer id) {
        this.id = id;
    }

    public TbContabilidade(Integer id, int cnpj, String nomeFantasia, String razaoSocial, String endereco, String enderecoNumero, String bairro, String municipio, String uf, int cep, BigDecimal comissao, Date dataInclusao) {
        this.id = id;
        this.cnpj = cnpj;
        this.nomeFantasia = nomeFantasia;
        this.razaoSocial = razaoSocial;
        this.endereco = endereco;
        this.enderecoNumero = enderecoNumero;
        this.bairro = bairro;
        this.municipio = municipio;
        this.uf = uf;
        this.cep = cep;
        this.comissao = comissao;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getCnpj() {
        return cnpj;
    }

    public void setCnpj(int cnpj) {
        this.cnpj = cnpj;
    }

    public String getInscricaoEstadual() {
        return inscricaoEstadual;
    }

    public void setInscricaoEstadual(String inscricaoEstadual) {
        this.inscricaoEstadual = inscricaoEstadual;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getEnderecoNumero() {
        return enderecoNumero;
    }

    public void setEnderecoNumero(String enderecoNumero) {
        this.enderecoNumero = enderecoNumero;
    }

    public String getEnderecoComplemento() {
        return enderecoComplemento;
    }

    public void setEnderecoComplemento(String enderecoComplemento) {
        this.enderecoComplemento = enderecoComplemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public int getCep() {
        return cep;
    }

    public void setCep(int cep) {
        this.cep = cep;
    }

    public BigDecimal getComissao() {
        return comissao;
    }

    public void setComissao(BigDecimal comissao) {
        this.comissao = comissao;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    @XmlTransient
    public Collection<TbContabilidadetbUsuarios> getTbContabilidadetbUsuariosCollection() {
        return tbContabilidadetbUsuariosCollection;
    }

    public void setTbContabilidadetbUsuariosCollection(Collection<TbContabilidadetbUsuarios> tbContabilidadetbUsuariosCollection) {
        this.tbContabilidadetbUsuariosCollection = tbContabilidadetbUsuariosCollection;
    }

    @XmlTransient
    public Collection<TbAssinantestbContabilidade> getTbAssinantestbContabilidadeCollection() {
        return tbAssinantestbContabilidadeCollection;
    }

    public void setTbAssinantestbContabilidadeCollection(Collection<TbAssinantestbContabilidade> tbAssinantestbContabilidadeCollection) {
        this.tbAssinantestbContabilidadeCollection = tbAssinantestbContabilidadeCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbContabilidade)) {
            return false;
        }
        TbContabilidade other = (TbContabilidade) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbContabilidade[ id=" + id + " ]";
    }
    
}
