/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbNFeConfiguracoes")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbNFeConfiguracoes.findAll", query = "SELECT t FROM TbNFeConfiguracoes t"),
    @NamedQuery(name = "TbNFeConfiguracoes.findById", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.id = :id"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByDownloadBaixarArquivoXML", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.downloadBaixarArquivoXML = :downloadBaixarArquivoXML"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByDownloadBaixarArquivoPDF", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.downloadBaixarArquivoPDF = :downloadBaixarArquivoPDF"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByDownloadCompactarArquivoFormatoZIP", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.downloadCompactarArquivoFormatoZIP = :downloadCompactarArquivoFormatoZIP"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailEnderecoServidorPop", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailEnderecoServidorPop = :enviarEmailEnderecoServidorPop"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailSemEncriptacao", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailSemEncriptacao = :enviarEmailSemEncriptacao"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailComEncriptacaoSSL", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailComEncriptacaoSSL = :enviarEmailComEncriptacaoSSL"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailPorta", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailPorta = :enviarEmailPorta"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailRequerAutenticacao", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailRequerAutenticacao = :enviarEmailRequerAutenticacao"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailRemetenteEmail", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailRemetenteEmail = :enviarEmailRemetenteEmail"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailRemetenteSenha", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailRemetenteSenha = :enviarEmailRemetenteSenha"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailDestino", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailDestino = :enviarEmailDestino"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailEnviarArquivoXML", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailEnviarArquivoXML = :enviarEmailEnviarArquivoXML"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailEnviarArquivoPDF", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailEnviarArquivoPDF = :enviarEmailEnviarArquivoPDF"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByEnviarEmailCompactarArquivoFormatoZIP", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.enviarEmailCompactarArquivoFormatoZIP = :enviarEmailCompactarArquivoFormatoZIP"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByReceberEmailEnderecoServidorSMTP", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.receberEmailEnderecoServidorSMTP = :receberEmailEnderecoServidorSMTP"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByReceberEmailSemEncriptacao", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.receberEmailSemEncriptacao = :receberEmailSemEncriptacao"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByReceberEmailComEncriptacaoSSL", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.receberEmailComEncriptacaoSSL = :receberEmailComEncriptacaoSSL"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByReceberEmailComEncriptacaoTLS", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.receberEmailComEncriptacaoTLS = :receberEmailComEncriptacaoTLS"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByReceberEmailPorta", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.receberEmailPorta = :receberEmailPorta"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByReceberEmailRequerAutenticacao", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.receberEmailRequerAutenticacao = :receberEmailRequerAutenticacao"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByReceberEmailRemetenteEmail", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.receberEmailRemetenteEmail = :receberEmailRemetenteEmail"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByReceberEmailRemetenteSenha", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.receberEmailRemetenteSenha = :receberEmailRemetenteSenha"),
    @NamedQuery(name = "TbNFeConfiguracoes.findByDataInclusao", query = "SELECT t FROM TbNFeConfiguracoes t WHERE t.dataInclusao = :dataInclusao")})
public class TbNFeConfiguracoes implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DownloadBaixarArquivoXML")
    private boolean downloadBaixarArquivoXML;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DownloadBaixarArquivoPDF")
    private boolean downloadBaixarArquivoPDF;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DownloadCompactarArquivoFormatoZIP")
    private boolean downloadCompactarArquivoFormatoZIP;
    @Size(max = 120)
    @Column(name = "EnviarEmailEnderecoServidorPop")
    private String enviarEmailEnderecoServidorPop;
    @Basic(optional = false)
    @NotNull
    @Column(name = "EnviarEmailSemEncriptacao")
    private boolean enviarEmailSemEncriptacao;
    @Basic(optional = false)
    @NotNull
    @Column(name = "EnviarEmailComEncriptacaoSSL")
    private boolean enviarEmailComEncriptacaoSSL;
    @Size(max = 5)
    @Column(name = "EnviarEmailPorta")
    private String enviarEmailPorta;
    @Basic(optional = false)
    @NotNull
    @Column(name = "EnviarEmailRequerAutenticacao")
    private boolean enviarEmailRequerAutenticacao;
    @Size(max = 60)
    @Column(name = "EnviarEmailRemetenteEmail")
    private String enviarEmailRemetenteEmail;
    @Size(max = 60)
    @Column(name = "EnviarEmailRemetenteSenha")
    private String enviarEmailRemetenteSenha;
    @Size(max = 60)
    @Column(name = "EnviarEmailDestino")
    private String enviarEmailDestino;
    @Basic(optional = false)
    @NotNull
    @Column(name = "EnviarEmailEnviarArquivoXML")
    private boolean enviarEmailEnviarArquivoXML;
    @Basic(optional = false)
    @NotNull
    @Column(name = "EnviarEmailEnviarArquivoPDF")
    private boolean enviarEmailEnviarArquivoPDF;
    @Basic(optional = false)
    @NotNull
    @Column(name = "EnviarEmailCompactarArquivoFormatoZIP")
    private boolean enviarEmailCompactarArquivoFormatoZIP;
    @Size(max = 120)
    @Column(name = "ReceberEmailEnderecoServidorSMTP")
    private String receberEmailEnderecoServidorSMTP;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ReceberEmailSemEncriptacao")
    private boolean receberEmailSemEncriptacao;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ReceberEmailComEncriptacaoSSL")
    private boolean receberEmailComEncriptacaoSSL;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ReceberEmailComEncriptacaoTLS")
    private boolean receberEmailComEncriptacaoTLS;
    @Size(max = 5)
    @Column(name = "ReceberEmailPorta")
    private String receberEmailPorta;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ReceberEmailRequerAutenticacao")
    private boolean receberEmailRequerAutenticacao;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "ReceberEmailRemetenteEmail")
    private String receberEmailRemetenteEmail;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "ReceberEmailRemetenteSenha")
    private String receberEmailRemetenteSenha;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "tbNFeConfiguracoesId")
    private TbAssinantestbNFe tbAssinantestbNFe;

    public TbNFeConfiguracoes() {
    }

    public TbNFeConfiguracoes(Integer id) {
        this.id = id;
    }

    public TbNFeConfiguracoes(Integer id, boolean downloadBaixarArquivoXML, boolean downloadBaixarArquivoPDF, boolean downloadCompactarArquivoFormatoZIP, boolean enviarEmailSemEncriptacao, boolean enviarEmailComEncriptacaoSSL, boolean enviarEmailRequerAutenticacao, boolean enviarEmailEnviarArquivoXML, boolean enviarEmailEnviarArquivoPDF, boolean enviarEmailCompactarArquivoFormatoZIP, boolean receberEmailSemEncriptacao, boolean receberEmailComEncriptacaoSSL, boolean receberEmailComEncriptacaoTLS, boolean receberEmailRequerAutenticacao, String receberEmailRemetenteEmail, String receberEmailRemetenteSenha, Date dataInclusao) {
        this.id = id;
        this.downloadBaixarArquivoXML = downloadBaixarArquivoXML;
        this.downloadBaixarArquivoPDF = downloadBaixarArquivoPDF;
        this.downloadCompactarArquivoFormatoZIP = downloadCompactarArquivoFormatoZIP;
        this.enviarEmailSemEncriptacao = enviarEmailSemEncriptacao;
        this.enviarEmailComEncriptacaoSSL = enviarEmailComEncriptacaoSSL;
        this.enviarEmailRequerAutenticacao = enviarEmailRequerAutenticacao;
        this.enviarEmailEnviarArquivoXML = enviarEmailEnviarArquivoXML;
        this.enviarEmailEnviarArquivoPDF = enviarEmailEnviarArquivoPDF;
        this.enviarEmailCompactarArquivoFormatoZIP = enviarEmailCompactarArquivoFormatoZIP;
        this.receberEmailSemEncriptacao = receberEmailSemEncriptacao;
        this.receberEmailComEncriptacaoSSL = receberEmailComEncriptacaoSSL;
        this.receberEmailComEncriptacaoTLS = receberEmailComEncriptacaoTLS;
        this.receberEmailRequerAutenticacao = receberEmailRequerAutenticacao;
        this.receberEmailRemetenteEmail = receberEmailRemetenteEmail;
        this.receberEmailRemetenteSenha = receberEmailRemetenteSenha;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public boolean getDownloadBaixarArquivoXML() {
        return downloadBaixarArquivoXML;
    }

    public void setDownloadBaixarArquivoXML(boolean downloadBaixarArquivoXML) {
        this.downloadBaixarArquivoXML = downloadBaixarArquivoXML;
    }

    public boolean getDownloadBaixarArquivoPDF() {
        return downloadBaixarArquivoPDF;
    }

    public void setDownloadBaixarArquivoPDF(boolean downloadBaixarArquivoPDF) {
        this.downloadBaixarArquivoPDF = downloadBaixarArquivoPDF;
    }

    public boolean getDownloadCompactarArquivoFormatoZIP() {
        return downloadCompactarArquivoFormatoZIP;
    }

    public void setDownloadCompactarArquivoFormatoZIP(boolean downloadCompactarArquivoFormatoZIP) {
        this.downloadCompactarArquivoFormatoZIP = downloadCompactarArquivoFormatoZIP;
    }

    public String getEnviarEmailEnderecoServidorPop() {
        return enviarEmailEnderecoServidorPop;
    }

    public void setEnviarEmailEnderecoServidorPop(String enviarEmailEnderecoServidorPop) {
        this.enviarEmailEnderecoServidorPop = enviarEmailEnderecoServidorPop;
    }

    public boolean getEnviarEmailSemEncriptacao() {
        return enviarEmailSemEncriptacao;
    }

    public void setEnviarEmailSemEncriptacao(boolean enviarEmailSemEncriptacao) {
        this.enviarEmailSemEncriptacao = enviarEmailSemEncriptacao;
    }

    public boolean getEnviarEmailComEncriptacaoSSL() {
        return enviarEmailComEncriptacaoSSL;
    }

    public void setEnviarEmailComEncriptacaoSSL(boolean enviarEmailComEncriptacaoSSL) {
        this.enviarEmailComEncriptacaoSSL = enviarEmailComEncriptacaoSSL;
    }

    public String getEnviarEmailPorta() {
        return enviarEmailPorta;
    }

    public void setEnviarEmailPorta(String enviarEmailPorta) {
        this.enviarEmailPorta = enviarEmailPorta;
    }

    public boolean getEnviarEmailRequerAutenticacao() {
        return enviarEmailRequerAutenticacao;
    }

    public void setEnviarEmailRequerAutenticacao(boolean enviarEmailRequerAutenticacao) {
        this.enviarEmailRequerAutenticacao = enviarEmailRequerAutenticacao;
    }

    public String getEnviarEmailRemetenteEmail() {
        return enviarEmailRemetenteEmail;
    }

    public void setEnviarEmailRemetenteEmail(String enviarEmailRemetenteEmail) {
        this.enviarEmailRemetenteEmail = enviarEmailRemetenteEmail;
    }

    public String getEnviarEmailRemetenteSenha() {
        return enviarEmailRemetenteSenha;
    }

    public void setEnviarEmailRemetenteSenha(String enviarEmailRemetenteSenha) {
        this.enviarEmailRemetenteSenha = enviarEmailRemetenteSenha;
    }

    public String getEnviarEmailDestino() {
        return enviarEmailDestino;
    }

    public void setEnviarEmailDestino(String enviarEmailDestino) {
        this.enviarEmailDestino = enviarEmailDestino;
    }

    public boolean getEnviarEmailEnviarArquivoXML() {
        return enviarEmailEnviarArquivoXML;
    }

    public void setEnviarEmailEnviarArquivoXML(boolean enviarEmailEnviarArquivoXML) {
        this.enviarEmailEnviarArquivoXML = enviarEmailEnviarArquivoXML;
    }

    public boolean getEnviarEmailEnviarArquivoPDF() {
        return enviarEmailEnviarArquivoPDF;
    }

    public void setEnviarEmailEnviarArquivoPDF(boolean enviarEmailEnviarArquivoPDF) {
        this.enviarEmailEnviarArquivoPDF = enviarEmailEnviarArquivoPDF;
    }

    public boolean getEnviarEmailCompactarArquivoFormatoZIP() {
        return enviarEmailCompactarArquivoFormatoZIP;
    }

    public void setEnviarEmailCompactarArquivoFormatoZIP(boolean enviarEmailCompactarArquivoFormatoZIP) {
        this.enviarEmailCompactarArquivoFormatoZIP = enviarEmailCompactarArquivoFormatoZIP;
    }

    public String getReceberEmailEnderecoServidorSMTP() {
        return receberEmailEnderecoServidorSMTP;
    }

    public void setReceberEmailEnderecoServidorSMTP(String receberEmailEnderecoServidorSMTP) {
        this.receberEmailEnderecoServidorSMTP = receberEmailEnderecoServidorSMTP;
    }

    public boolean getReceberEmailSemEncriptacao() {
        return receberEmailSemEncriptacao;
    }

    public void setReceberEmailSemEncriptacao(boolean receberEmailSemEncriptacao) {
        this.receberEmailSemEncriptacao = receberEmailSemEncriptacao;
    }

    public boolean getReceberEmailComEncriptacaoSSL() {
        return receberEmailComEncriptacaoSSL;
    }

    public void setReceberEmailComEncriptacaoSSL(boolean receberEmailComEncriptacaoSSL) {
        this.receberEmailComEncriptacaoSSL = receberEmailComEncriptacaoSSL;
    }

    public boolean getReceberEmailComEncriptacaoTLS() {
        return receberEmailComEncriptacaoTLS;
    }

    public void setReceberEmailComEncriptacaoTLS(boolean receberEmailComEncriptacaoTLS) {
        this.receberEmailComEncriptacaoTLS = receberEmailComEncriptacaoTLS;
    }

    public String getReceberEmailPorta() {
        return receberEmailPorta;
    }

    public void setReceberEmailPorta(String receberEmailPorta) {
        this.receberEmailPorta = receberEmailPorta;
    }

    public boolean getReceberEmailRequerAutenticacao() {
        return receberEmailRequerAutenticacao;
    }

    public void setReceberEmailRequerAutenticacao(boolean receberEmailRequerAutenticacao) {
        this.receberEmailRequerAutenticacao = receberEmailRequerAutenticacao;
    }

    public String getReceberEmailRemetenteEmail() {
        return receberEmailRemetenteEmail;
    }

    public void setReceberEmailRemetenteEmail(String receberEmailRemetenteEmail) {
        this.receberEmailRemetenteEmail = receberEmailRemetenteEmail;
    }

    public String getReceberEmailRemetenteSenha() {
        return receberEmailRemetenteSenha;
    }

    public void setReceberEmailRemetenteSenha(String receberEmailRemetenteSenha) {
        this.receberEmailRemetenteSenha = receberEmailRemetenteSenha;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public TbAssinantestbNFe getTbAssinantestbNFe() {
        return tbAssinantestbNFe;
    }

    public void setTbAssinantestbNFe(TbAssinantestbNFe tbAssinantestbNFe) {
        this.tbAssinantestbNFe = tbAssinantestbNFe;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbNFeConfiguracoes)) {
            return false;
        }
        TbNFeConfiguracoes other = (TbNFeConfiguracoes) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbNFeConfiguracoes[ id=" + id + " ]";
    }
    
}
