/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbAssinantes_tbAssinantesCertificadoA1")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbAssinantestbAssinantesCertificadoA1.findAll", query = "SELECT t FROM TbAssinantestbAssinantesCertificadoA1 t"),
    @NamedQuery(name = "TbAssinantestbAssinantesCertificadoA1.findById", query = "SELECT t FROM TbAssinantestbAssinantesCertificadoA1 t WHERE t.id = :id"),
    @NamedQuery(name = "TbAssinantestbAssinantesCertificadoA1.findByTbAssinantesCertificadoA1Id", query = "SELECT t FROM TbAssinantestbAssinantesCertificadoA1 t WHERE t.tbAssinantesCertificadoA1Id = :tbAssinantesCertificadoA1Id"),
    @NamedQuery(name = "TbAssinantestbAssinantesCertificadoA1.findByDataInclusao", query = "SELECT t FROM TbAssinantestbAssinantesCertificadoA1 t WHERE t.dataInclusao = :dataInclusao")})
public class TbAssinantestbAssinantesCertificadoA1 implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "tbAssinantesCertificadoA1_Id")
    private int tbAssinantesCertificadoA1Id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @JoinColumn(name = "Id", referencedColumnName = "Id", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private TbAssinantesCertificadoA1 tbAssinantesCertificadoA1;
    @JoinColumn(name = "tbAssinantes_Id", referencedColumnName = "Id")
    @OneToOne(optional = false)
    private TbAssinantes tbAssinantesId;

    public TbAssinantestbAssinantesCertificadoA1() {
    }

    public TbAssinantestbAssinantesCertificadoA1(Integer id) {
        this.id = id;
    }

    public TbAssinantestbAssinantesCertificadoA1(Integer id, int tbAssinantesCertificadoA1Id, Date dataInclusao) {
        this.id = id;
        this.tbAssinantesCertificadoA1Id = tbAssinantesCertificadoA1Id;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getTbAssinantesCertificadoA1Id() {
        return tbAssinantesCertificadoA1Id;
    }

    public void setTbAssinantesCertificadoA1Id(int tbAssinantesCertificadoA1Id) {
        this.tbAssinantesCertificadoA1Id = tbAssinantesCertificadoA1Id;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public TbAssinantesCertificadoA1 getTbAssinantesCertificadoA1() {
        return tbAssinantesCertificadoA1;
    }

    public void setTbAssinantesCertificadoA1(TbAssinantesCertificadoA1 tbAssinantesCertificadoA1) {
        this.tbAssinantesCertificadoA1 = tbAssinantesCertificadoA1;
    }

    public TbAssinantes getTbAssinantesId() {
        return tbAssinantesId;
    }

    public void setTbAssinantesId(TbAssinantes tbAssinantesId) {
        this.tbAssinantesId = tbAssinantesId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbAssinantestbAssinantesCertificadoA1)) {
            return false;
        }
        TbAssinantestbAssinantesCertificadoA1 other = (TbAssinantestbAssinantesCertificadoA1) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbAssinantestbAssinantesCertificadoA1[ id=" + id + " ]";
    }
    
}
