/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbPlanos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbPlanos.findAll", query = "SELECT t FROM TbPlanos t"),
    @NamedQuery(name = "TbPlanos.findById", query = "SELECT t FROM TbPlanos t WHERE t.id = :id"),
    @NamedQuery(name = "TbPlanos.findByDescricao", query = "SELECT t FROM TbPlanos t WHERE t.descricao = :descricao"),
    @NamedQuery(name = "TbPlanos.findByFaixaInicial", query = "SELECT t FROM TbPlanos t WHERE t.faixaInicial = :faixaInicial"),
    @NamedQuery(name = "TbPlanos.findByFaixaFinal", query = "SELECT t FROM TbPlanos t WHERE t.faixaFinal = :faixaFinal"),
    @NamedQuery(name = "TbPlanos.findByValorMensal", query = "SELECT t FROM TbPlanos t WHERE t.valorMensal = :valorMensal"),
    @NamedQuery(name = "TbPlanos.findByValorDoctoAdicional", query = "SELECT t FROM TbPlanos t WHERE t.valorDoctoAdicional = :valorDoctoAdicional"),
    @NamedQuery(name = "TbPlanos.findByTipoInclusao", query = "SELECT t FROM TbPlanos t WHERE t.tipoInclusao = :tipoInclusao"),
    @NamedQuery(name = "TbPlanos.findByDataInclusao", query = "SELECT t FROM TbPlanos t WHERE t.dataInclusao = :dataInclusao")})
public class TbPlanos implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "Descricao")
    private String descricao;
    @Basic(optional = false)
    @NotNull
    @Column(name = "FaixaInicial")
    private int faixaInicial;
    @Basic(optional = false)
    @NotNull
    @Column(name = "FaixaFinal")
    private int faixaFinal;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "ValorMensal")
    private BigDecimal valorMensal;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ValorDoctoAdicional")
    private BigDecimal valorDoctoAdicional;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "TipoInclusao")
    private String tipoInclusao;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbPlanosId")
    private Collection<TbAssinantestbPlanos> tbAssinantestbPlanosCollection;

    public TbPlanos() {
    }

    public TbPlanos(Integer id) {
        this.id = id;
    }

    public TbPlanos(Integer id, String descricao, int faixaInicial, int faixaFinal, BigDecimal valorMensal, BigDecimal valorDoctoAdicional, String tipoInclusao, Date dataInclusao) {
        this.id = id;
        this.descricao = descricao;
        this.faixaInicial = faixaInicial;
        this.faixaFinal = faixaFinal;
        this.valorMensal = valorMensal;
        this.valorDoctoAdicional = valorDoctoAdicional;
        this.tipoInclusao = tipoInclusao;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getFaixaInicial() {
        return faixaInicial;
    }

    public void setFaixaInicial(int faixaInicial) {
        this.faixaInicial = faixaInicial;
    }

    public int getFaixaFinal() {
        return faixaFinal;
    }

    public void setFaixaFinal(int faixaFinal) {
        this.faixaFinal = faixaFinal;
    }

    public BigDecimal getValorMensal() {
        return valorMensal;
    }

    public void setValorMensal(BigDecimal valorMensal) {
        this.valorMensal = valorMensal;
    }

    public BigDecimal getValorDoctoAdicional() {
        return valorDoctoAdicional;
    }

    public void setValorDoctoAdicional(BigDecimal valorDoctoAdicional) {
        this.valorDoctoAdicional = valorDoctoAdicional;
    }

    public String getTipoInclusao() {
        return tipoInclusao;
    }

    public void setTipoInclusao(String tipoInclusao) {
        this.tipoInclusao = tipoInclusao;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    @XmlTransient
    public Collection<TbAssinantestbPlanos> getTbAssinantestbPlanosCollection() {
        return tbAssinantestbPlanosCollection;
    }

    public void setTbAssinantestbPlanosCollection(Collection<TbAssinantestbPlanos> tbAssinantestbPlanosCollection) {
        this.tbAssinantestbPlanosCollection = tbAssinantestbPlanosCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbPlanos)) {
            return false;
        }
        TbPlanos other = (TbPlanos) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbPlanos[ id=" + id + " ]";
    }
    
}
