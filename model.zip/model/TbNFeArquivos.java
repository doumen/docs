/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbNFeArquivos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbNFeArquivos.findAll", query = "SELECT t FROM TbNFeArquivos t"),
    @NamedQuery(name = "TbNFeArquivos.findById", query = "SELECT t FROM TbNFeArquivos t WHERE t.id = :id"),
    @NamedQuery(name = "TbNFeArquivos.findByDataInclusao", query = "SELECT t FROM TbNFeArquivos t WHERE t.dataInclusao = :dataInclusao")})
public class TbNFeArquivos implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "ArquivoNFeXML")
    private byte[] arquivoNFeXML;
    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "ArquivoDanfePDF")
    private byte[] arquivoDanfePDF;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbNFeArquivosId")
    private Collection<TbSpedFiscaltbNFe> tbSpedFiscaltbNFeCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbNFeArquivosId")
    private Collection<TbPisDependencias> tbPisDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbNFeArquivosId")
    private Collection<TbFaturasDependencias> tbFaturasDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbNFeArquivosId")
    private Collection<TbCofinsDependencias> tbCofinsDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbNFeArquivosId")
    private Collection<TbProdutosDependencias> tbProdutosDependenciasCollection;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "tbNFeArquivosId")
    private TbAssinantestbNFe tbAssinantestbNFe;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbNFeArquivosId")
    private Collection<TbCTetbNFe> tbCTetbNFeCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbNFeArquivosId")
    private Collection<TbIpiDependencias> tbIpiDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbNFeArquivosId")
    private Collection<TbSpedContribuicoestbNFe> tbSpedContribuicoestbNFeCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbNFeArquivosId")
    private Collection<TbIcmsDependencias> tbIcmsDependenciasCollection;

    public TbNFeArquivos() {
    }

    public TbNFeArquivos(Integer id) {
        this.id = id;
    }

    public TbNFeArquivos(Integer id, byte[] arquivoNFeXML, byte[] arquivoDanfePDF, Date dataInclusao) {
        this.id = id;
        this.arquivoNFeXML = arquivoNFeXML;
        this.arquivoDanfePDF = arquivoDanfePDF;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public byte[] getArquivoNFeXML() {
        return arquivoNFeXML;
    }

    public void setArquivoNFeXML(byte[] arquivoNFeXML) {
        this.arquivoNFeXML = arquivoNFeXML;
    }

    public byte[] getArquivoDanfePDF() {
        return arquivoDanfePDF;
    }

    public void setArquivoDanfePDF(byte[] arquivoDanfePDF) {
        this.arquivoDanfePDF = arquivoDanfePDF;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    @XmlTransient
    public Collection<TbSpedFiscaltbNFe> getTbSpedFiscaltbNFeCollection() {
        return tbSpedFiscaltbNFeCollection;
    }

    public void setTbSpedFiscaltbNFeCollection(Collection<TbSpedFiscaltbNFe> tbSpedFiscaltbNFeCollection) {
        this.tbSpedFiscaltbNFeCollection = tbSpedFiscaltbNFeCollection;
    }

    @XmlTransient
    public Collection<TbPisDependencias> getTbPisDependenciasCollection() {
        return tbPisDependenciasCollection;
    }

    public void setTbPisDependenciasCollection(Collection<TbPisDependencias> tbPisDependenciasCollection) {
        this.tbPisDependenciasCollection = tbPisDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbFaturasDependencias> getTbFaturasDependenciasCollection() {
        return tbFaturasDependenciasCollection;
    }

    public void setTbFaturasDependenciasCollection(Collection<TbFaturasDependencias> tbFaturasDependenciasCollection) {
        this.tbFaturasDependenciasCollection = tbFaturasDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbCofinsDependencias> getTbCofinsDependenciasCollection() {
        return tbCofinsDependenciasCollection;
    }

    public void setTbCofinsDependenciasCollection(Collection<TbCofinsDependencias> tbCofinsDependenciasCollection) {
        this.tbCofinsDependenciasCollection = tbCofinsDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbProdutosDependencias> getTbProdutosDependenciasCollection() {
        return tbProdutosDependenciasCollection;
    }

    public void setTbProdutosDependenciasCollection(Collection<TbProdutosDependencias> tbProdutosDependenciasCollection) {
        this.tbProdutosDependenciasCollection = tbProdutosDependenciasCollection;
    }

    public TbAssinantestbNFe getTbAssinantestbNFe() {
        return tbAssinantestbNFe;
    }

    public void setTbAssinantestbNFe(TbAssinantestbNFe tbAssinantestbNFe) {
        this.tbAssinantestbNFe = tbAssinantestbNFe;
    }

    @XmlTransient
    public Collection<TbCTetbNFe> getTbCTetbNFeCollection() {
        return tbCTetbNFeCollection;
    }

    public void setTbCTetbNFeCollection(Collection<TbCTetbNFe> tbCTetbNFeCollection) {
        this.tbCTetbNFeCollection = tbCTetbNFeCollection;
    }

    @XmlTransient
    public Collection<TbIpiDependencias> getTbIpiDependenciasCollection() {
        return tbIpiDependenciasCollection;
    }

    public void setTbIpiDependenciasCollection(Collection<TbIpiDependencias> tbIpiDependenciasCollection) {
        this.tbIpiDependenciasCollection = tbIpiDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbSpedContribuicoestbNFe> getTbSpedContribuicoestbNFeCollection() {
        return tbSpedContribuicoestbNFeCollection;
    }

    public void setTbSpedContribuicoestbNFeCollection(Collection<TbSpedContribuicoestbNFe> tbSpedContribuicoestbNFeCollection) {
        this.tbSpedContribuicoestbNFeCollection = tbSpedContribuicoestbNFeCollection;
    }

    @XmlTransient
    public Collection<TbIcmsDependencias> getTbIcmsDependenciasCollection() {
        return tbIcmsDependenciasCollection;
    }

    public void setTbIcmsDependenciasCollection(Collection<TbIcmsDependencias> tbIcmsDependenciasCollection) {
        this.tbIcmsDependenciasCollection = tbIcmsDependenciasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbNFeArquivos)) {
            return false;
        }
        TbNFeArquivos other = (TbNFeArquivos) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbNFeArquivos[ id=" + id + " ]";
    }
    
}
