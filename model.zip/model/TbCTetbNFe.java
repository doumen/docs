/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbCTe_tbNFe")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbCTetbNFe.findAll", query = "SELECT t FROM TbCTetbNFe t"),
    @NamedQuery(name = "TbCTetbNFe.findById", query = "SELECT t FROM TbCTetbNFe t WHERE t.id = :id"),
    @NamedQuery(name = "TbCTetbNFe.findByDataInclusao", query = "SELECT t FROM TbCTetbNFe t WHERE t.dataInclusao = :dataInclusao")})
public class TbCTetbNFe implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @JoinColumn(name = "tbCTe_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbCTe tbCTeId;
    @JoinColumn(name = "tbCTeArquivos_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbCTeArquivos tbCTeArquivosId;
    @JoinColumn(name = "tbNFe_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbNFe tbNFeId;
    @JoinColumn(name = "tbNFeArquivos_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbNFeArquivos tbNFeArquivosId;

    public TbCTetbNFe() {
    }

    public TbCTetbNFe(Integer id) {
        this.id = id;
    }

    public TbCTetbNFe(Integer id, Date dataInclusao) {
        this.id = id;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public TbCTe getTbCTeId() {
        return tbCTeId;
    }

    public void setTbCTeId(TbCTe tbCTeId) {
        this.tbCTeId = tbCTeId;
    }

    public TbCTeArquivos getTbCTeArquivosId() {
        return tbCTeArquivosId;
    }

    public void setTbCTeArquivosId(TbCTeArquivos tbCTeArquivosId) {
        this.tbCTeArquivosId = tbCTeArquivosId;
    }

    public TbNFe getTbNFeId() {
        return tbNFeId;
    }

    public void setTbNFeId(TbNFe tbNFeId) {
        this.tbNFeId = tbNFeId;
    }

    public TbNFeArquivos getTbNFeArquivosId() {
        return tbNFeArquivosId;
    }

    public void setTbNFeArquivosId(TbNFeArquivos tbNFeArquivosId) {
        this.tbNFeArquivosId = tbNFeArquivosId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbCTetbNFe)) {
            return false;
        }
        TbCTetbNFe other = (TbCTetbNFe) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbCTetbNFe[ id=" + id + " ]";
    }
    
}
