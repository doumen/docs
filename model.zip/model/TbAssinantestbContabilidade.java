/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbAssinantes_tbContabilidade")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbAssinantestbContabilidade.findAll", query = "SELECT t FROM TbAssinantestbContabilidade t"),
    @NamedQuery(name = "TbAssinantestbContabilidade.findById", query = "SELECT t FROM TbAssinantestbContabilidade t WHERE t.id = :id"),
    @NamedQuery(name = "TbAssinantestbContabilidade.findByDataInclusao", query = "SELECT t FROM TbAssinantestbContabilidade t WHERE t.dataInclusao = :dataInclusao")})
public class TbAssinantestbContabilidade implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @JoinColumn(name = "tbAssinantes_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbAssinantes tbAssinantesId;
    @JoinColumn(name = "tbContabilidade_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbContabilidade tbContabilidadeId;

    public TbAssinantestbContabilidade() {
    }

    public TbAssinantestbContabilidade(Integer id) {
        this.id = id;
    }

    public TbAssinantestbContabilidade(Integer id, Date dataInclusao) {
        this.id = id;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public TbAssinantes getTbAssinantesId() {
        return tbAssinantesId;
    }

    public void setTbAssinantesId(TbAssinantes tbAssinantesId) {
        this.tbAssinantesId = tbAssinantesId;
    }

    public TbContabilidade getTbContabilidadeId() {
        return tbContabilidadeId;
    }

    public void setTbContabilidadeId(TbContabilidade tbContabilidadeId) {
        this.tbContabilidadeId = tbContabilidadeId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbAssinantestbContabilidade)) {
            return false;
        }
        TbAssinantestbContabilidade other = (TbAssinantestbContabilidade) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbAssinantestbContabilidade[ id=" + id + " ]";
    }
    
}
