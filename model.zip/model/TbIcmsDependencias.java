/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbIcms_Dependencias")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbIcmsDependencias.findAll", query = "SELECT t FROM TbIcmsDependencias t"),
    @NamedQuery(name = "TbIcmsDependencias.findById", query = "SELECT t FROM TbIcmsDependencias t WHERE t.id = :id"),
    @NamedQuery(name = "TbIcmsDependencias.findByDataInclusao", query = "SELECT t FROM TbIcmsDependencias t WHERE t.dataInclusao = :dataInclusao")})
public class TbIcmsDependencias implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @JoinColumn(name = "tbModalidadeDeterminacaoBaseCalculoIcmsSt_Id", referencedColumnName = "Id")
    @ManyToOne
    private TbModelalidadeDeterminacaoBaseCalculoIcmsSt tbModalidadeDeterminacaoBaseCalculoIcmsStId;
    @JoinColumn(name = "tbAssinantes_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbAssinantes tbAssinantesId;
    @JoinColumn(name = "tbCstIcms_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbCstIcms tbCstIcmsId;
    @JoinColumn(name = "tbCstIcmsOrigem_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbCstIcmsOrigem tbCstIcmsOrigemId;
    @JoinColumn(name = "tbIcms_Id", referencedColumnName = "Id")
    @ManyToOne
    private TbIcms tbIcmsId;
    @JoinColumn(name = "tbIcmsSt_Id", referencedColumnName = "Id")
    @ManyToOne
    private TbIcmsSt tbIcmsStId;
    @JoinColumn(name = "tbModalidadeDeterminacaoBaseCalculoIcms_Id", referencedColumnName = "Id")
    @ManyToOne
    private TbModelalidadeDeterminacaoBaseCalculoIcms tbModalidadeDeterminacaoBaseCalculoIcmsId;
    @JoinColumn(name = "tbNFe_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbNFe tbNFeId;
    @JoinColumn(name = "tbNFeArquivos_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbNFeArquivos tbNFeArquivosId;
    @JoinColumn(name = "tbNFeItens_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbNFeItens tbNFeItensId;
    @JoinColumn(name = "tbProduto_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbProdutos tbProdutoId;

    public TbIcmsDependencias() {
    }

    public TbIcmsDependencias(Integer id) {
        this.id = id;
    }

    public TbIcmsDependencias(Integer id, Date dataInclusao) {
        this.id = id;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public TbModelalidadeDeterminacaoBaseCalculoIcmsSt getTbModalidadeDeterminacaoBaseCalculoIcmsStId() {
        return tbModalidadeDeterminacaoBaseCalculoIcmsStId;
    }

    public void setTbModalidadeDeterminacaoBaseCalculoIcmsStId(TbModelalidadeDeterminacaoBaseCalculoIcmsSt tbModalidadeDeterminacaoBaseCalculoIcmsStId) {
        this.tbModalidadeDeterminacaoBaseCalculoIcmsStId = tbModalidadeDeterminacaoBaseCalculoIcmsStId;
    }

    public TbAssinantes getTbAssinantesId() {
        return tbAssinantesId;
    }

    public void setTbAssinantesId(TbAssinantes tbAssinantesId) {
        this.tbAssinantesId = tbAssinantesId;
    }

    public TbCstIcms getTbCstIcmsId() {
        return tbCstIcmsId;
    }

    public void setTbCstIcmsId(TbCstIcms tbCstIcmsId) {
        this.tbCstIcmsId = tbCstIcmsId;
    }

    public TbCstIcmsOrigem getTbCstIcmsOrigemId() {
        return tbCstIcmsOrigemId;
    }

    public void setTbCstIcmsOrigemId(TbCstIcmsOrigem tbCstIcmsOrigemId) {
        this.tbCstIcmsOrigemId = tbCstIcmsOrigemId;
    }

    public TbIcms getTbIcmsId() {
        return tbIcmsId;
    }

    public void setTbIcmsId(TbIcms tbIcmsId) {
        this.tbIcmsId = tbIcmsId;
    }

    public TbIcmsSt getTbIcmsStId() {
        return tbIcmsStId;
    }

    public void setTbIcmsStId(TbIcmsSt tbIcmsStId) {
        this.tbIcmsStId = tbIcmsStId;
    }

    public TbModelalidadeDeterminacaoBaseCalculoIcms getTbModalidadeDeterminacaoBaseCalculoIcmsId() {
        return tbModalidadeDeterminacaoBaseCalculoIcmsId;
    }

    public void setTbModalidadeDeterminacaoBaseCalculoIcmsId(TbModelalidadeDeterminacaoBaseCalculoIcms tbModalidadeDeterminacaoBaseCalculoIcmsId) {
        this.tbModalidadeDeterminacaoBaseCalculoIcmsId = tbModalidadeDeterminacaoBaseCalculoIcmsId;
    }

    public TbNFe getTbNFeId() {
        return tbNFeId;
    }

    public void setTbNFeId(TbNFe tbNFeId) {
        this.tbNFeId = tbNFeId;
    }

    public TbNFeArquivos getTbNFeArquivosId() {
        return tbNFeArquivosId;
    }

    public void setTbNFeArquivosId(TbNFeArquivos tbNFeArquivosId) {
        this.tbNFeArquivosId = tbNFeArquivosId;
    }

    public TbNFeItens getTbNFeItensId() {
        return tbNFeItensId;
    }

    public void setTbNFeItensId(TbNFeItens tbNFeItensId) {
        this.tbNFeItensId = tbNFeItensId;
    }

    public TbProdutos getTbProdutoId() {
        return tbProdutoId;
    }

    public void setTbProdutoId(TbProdutos tbProdutoId) {
        this.tbProdutoId = tbProdutoId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbIcmsDependencias)) {
            return false;
        }
        TbIcmsDependencias other = (TbIcmsDependencias) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbIcmsDependencias[ id=" + id + " ]";
    }
    
}
