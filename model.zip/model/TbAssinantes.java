/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbAssinantes")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbAssinantes.findAll", query = "SELECT t FROM TbAssinantes t"),
    @NamedQuery(name = "TbAssinantes.findById", query = "SELECT t FROM TbAssinantes t WHERE t.id = :id"),
    @NamedQuery(name = "TbAssinantes.findByCnpj", query = "SELECT t FROM TbAssinantes t WHERE t.cnpj = :cnpj"),
    @NamedQuery(name = "TbAssinantes.findByInscricaoEstadual", query = "SELECT t FROM TbAssinantes t WHERE t.inscricaoEstadual = :inscricaoEstadual"),
    @NamedQuery(name = "TbAssinantes.findByNomeFantasia", query = "SELECT t FROM TbAssinantes t WHERE t.nomeFantasia = :nomeFantasia"),
    @NamedQuery(name = "TbAssinantes.findByRazaoSocial", query = "SELECT t FROM TbAssinantes t WHERE t.razaoSocial = :razaoSocial"),
    @NamedQuery(name = "TbAssinantes.findByEndereco", query = "SELECT t FROM TbAssinantes t WHERE t.endereco = :endereco"),
    @NamedQuery(name = "TbAssinantes.findByEnderecoNumero", query = "SELECT t FROM TbAssinantes t WHERE t.enderecoNumero = :enderecoNumero"),
    @NamedQuery(name = "TbAssinantes.findByEnderecoComplemento", query = "SELECT t FROM TbAssinantes t WHERE t.enderecoComplemento = :enderecoComplemento"),
    @NamedQuery(name = "TbAssinantes.findByBairro", query = "SELECT t FROM TbAssinantes t WHERE t.bairro = :bairro"),
    @NamedQuery(name = "TbAssinantes.findByMunicipio", query = "SELECT t FROM TbAssinantes t WHERE t.municipio = :municipio"),
    @NamedQuery(name = "TbAssinantes.findByUf", query = "SELECT t FROM TbAssinantes t WHERE t.uf = :uf"),
    @NamedQuery(name = "TbAssinantes.findByCep", query = "SELECT t FROM TbAssinantes t WHERE t.cep = :cep"),
    @NamedQuery(name = "TbAssinantes.findByEmailMaster", query = "SELECT t FROM TbAssinantes t WHERE t.emailMaster = :emailMaster"),
    @NamedQuery(name = "TbAssinantes.findByEmailFinanceiro", query = "SELECT t FROM TbAssinantes t WHERE t.emailFinanceiro = :emailFinanceiro"),
    @NamedQuery(name = "TbAssinantes.findByDataInclusao", query = "SELECT t FROM TbAssinantes t WHERE t.dataInclusao = :dataInclusao")})
public class TbAssinantes implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 14)
    @Column(name = "Cnpj")
    private String cnpj;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 14)
    @Column(name = "InscricaoEstadual")
    private String inscricaoEstadual;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "NomeFantasia")
    private String nomeFantasia;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "RazaoSocial")
    private String razaoSocial;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "Endereco")
    private String endereco;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 8)
    @Column(name = "EnderecoNumero")
    private String enderecoNumero;
    @Size(max = 60)
    @Column(name = "EnderecoComplemento")
    private String enderecoComplemento;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Bairro")
    private String bairro;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Municipio")
    private String municipio;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "Uf")
    private String uf;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Cep")
    private int cep;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "EmailMaster")
    private String emailMaster;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "EmailFinanceiro")
    private String emailFinanceiro;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbAssinantestbUsuarios> tbAssinantestbUsuariosCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbAssinantestbSpedContribuicoes> tbAssinantestbSpedContribuicoesCollection;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private TbAssinantestbAssinantesCertificadoA1 tbAssinantestbAssinantesCertificadoA1;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbAssinantestbPlanos> tbAssinantestbPlanosCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbPisDependencias> tbPisDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbAssinantestbContabilidade> tbAssinantestbContabilidadeCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbAssinantestbSpedSocial> tbAssinantestbSpedSocialCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbFaturasDependencias> tbFaturasDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbAssinantestbSpedFiscal> tbAssinantestbSpedFiscalCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbCofinsDependencias> tbCofinsDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbProdutosDependencias> tbProdutosDependenciasCollection;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private TbAssinantestbNFe tbAssinantestbNFe;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbNFetbNFeItens> tbNFetbNFeItensCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbIpiDependencias> tbIpiDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbIcmsDependencias> tbIcmsDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbAssinantesId")
    private Collection<TbAssinantestbCTe> tbAssinantestbCTeCollection;

    public TbAssinantes() {
    }

    public TbAssinantes(Integer id) {
        this.id = id;
    }

    public TbAssinantes(Integer id, String cnpj, String inscricaoEstadual, String nomeFantasia, String razaoSocial, String endereco, String enderecoNumero, String bairro, String municipio, String uf, int cep, String emailMaster, String emailFinanceiro, Date dataInclusao) {
        this.id = id;
        this.cnpj = cnpj;
        this.inscricaoEstadual = inscricaoEstadual;
        this.nomeFantasia = nomeFantasia;
        this.razaoSocial = razaoSocial;
        this.endereco = endereco;
        this.enderecoNumero = enderecoNumero;
        this.bairro = bairro;
        this.municipio = municipio;
        this.uf = uf;
        this.cep = cep;
        this.emailMaster = emailMaster;
        this.emailFinanceiro = emailFinanceiro;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getInscricaoEstadual() {
        return inscricaoEstadual;
    }

    public void setInscricaoEstadual(String inscricaoEstadual) {
        this.inscricaoEstadual = inscricaoEstadual;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getEnderecoNumero() {
        return enderecoNumero;
    }

    public void setEnderecoNumero(String enderecoNumero) {
        this.enderecoNumero = enderecoNumero;
    }

    public String getEnderecoComplemento() {
        return enderecoComplemento;
    }

    public void setEnderecoComplemento(String enderecoComplemento) {
        this.enderecoComplemento = enderecoComplemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public int getCep() {
        return cep;
    }

    public void setCep(int cep) {
        this.cep = cep;
    }

    public String getEmailMaster() {
        return emailMaster;
    }

    public void setEmailMaster(String emailMaster) {
        this.emailMaster = emailMaster;
    }

    public String getEmailFinanceiro() {
        return emailFinanceiro;
    }

    public void setEmailFinanceiro(String emailFinanceiro) {
        this.emailFinanceiro = emailFinanceiro;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    @XmlTransient
    public Collection<TbAssinantestbUsuarios> getTbAssinantestbUsuariosCollection() {
        return tbAssinantestbUsuariosCollection;
    }

    public void setTbAssinantestbUsuariosCollection(Collection<TbAssinantestbUsuarios> tbAssinantestbUsuariosCollection) {
        this.tbAssinantestbUsuariosCollection = tbAssinantestbUsuariosCollection;
    }

    @XmlTransient
    public Collection<TbAssinantestbSpedContribuicoes> getTbAssinantestbSpedContribuicoesCollection() {
        return tbAssinantestbSpedContribuicoesCollection;
    }

    public void setTbAssinantestbSpedContribuicoesCollection(Collection<TbAssinantestbSpedContribuicoes> tbAssinantestbSpedContribuicoesCollection) {
        this.tbAssinantestbSpedContribuicoesCollection = tbAssinantestbSpedContribuicoesCollection;
    }

    public TbAssinantestbAssinantesCertificadoA1 getTbAssinantestbAssinantesCertificadoA1() {
        return tbAssinantestbAssinantesCertificadoA1;
    }

    public void setTbAssinantestbAssinantesCertificadoA1(TbAssinantestbAssinantesCertificadoA1 tbAssinantestbAssinantesCertificadoA1) {
        this.tbAssinantestbAssinantesCertificadoA1 = tbAssinantestbAssinantesCertificadoA1;
    }

    @XmlTransient
    public Collection<TbAssinantestbPlanos> getTbAssinantestbPlanosCollection() {
        return tbAssinantestbPlanosCollection;
    }

    public void setTbAssinantestbPlanosCollection(Collection<TbAssinantestbPlanos> tbAssinantestbPlanosCollection) {
        this.tbAssinantestbPlanosCollection = tbAssinantestbPlanosCollection;
    }

    @XmlTransient
    public Collection<TbPisDependencias> getTbPisDependenciasCollection() {
        return tbPisDependenciasCollection;
    }

    public void setTbPisDependenciasCollection(Collection<TbPisDependencias> tbPisDependenciasCollection) {
        this.tbPisDependenciasCollection = tbPisDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbAssinantestbContabilidade> getTbAssinantestbContabilidadeCollection() {
        return tbAssinantestbContabilidadeCollection;
    }

    public void setTbAssinantestbContabilidadeCollection(Collection<TbAssinantestbContabilidade> tbAssinantestbContabilidadeCollection) {
        this.tbAssinantestbContabilidadeCollection = tbAssinantestbContabilidadeCollection;
    }

    @XmlTransient
    public Collection<TbAssinantestbSpedSocial> getTbAssinantestbSpedSocialCollection() {
        return tbAssinantestbSpedSocialCollection;
    }

    public void setTbAssinantestbSpedSocialCollection(Collection<TbAssinantestbSpedSocial> tbAssinantestbSpedSocialCollection) {
        this.tbAssinantestbSpedSocialCollection = tbAssinantestbSpedSocialCollection;
    }

    @XmlTransient
    public Collection<TbFaturasDependencias> getTbFaturasDependenciasCollection() {
        return tbFaturasDependenciasCollection;
    }

    public void setTbFaturasDependenciasCollection(Collection<TbFaturasDependencias> tbFaturasDependenciasCollection) {
        this.tbFaturasDependenciasCollection = tbFaturasDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbAssinantestbSpedFiscal> getTbAssinantestbSpedFiscalCollection() {
        return tbAssinantestbSpedFiscalCollection;
    }

    public void setTbAssinantestbSpedFiscalCollection(Collection<TbAssinantestbSpedFiscal> tbAssinantestbSpedFiscalCollection) {
        this.tbAssinantestbSpedFiscalCollection = tbAssinantestbSpedFiscalCollection;
    }

    @XmlTransient
    public Collection<TbCofinsDependencias> getTbCofinsDependenciasCollection() {
        return tbCofinsDependenciasCollection;
    }

    public void setTbCofinsDependenciasCollection(Collection<TbCofinsDependencias> tbCofinsDependenciasCollection) {
        this.tbCofinsDependenciasCollection = tbCofinsDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbProdutosDependencias> getTbProdutosDependenciasCollection() {
        return tbProdutosDependenciasCollection;
    }

    public void setTbProdutosDependenciasCollection(Collection<TbProdutosDependencias> tbProdutosDependenciasCollection) {
        this.tbProdutosDependenciasCollection = tbProdutosDependenciasCollection;
    }

    public TbAssinantestbNFe getTbAssinantestbNFe() {
        return tbAssinantestbNFe;
    }

    public void setTbAssinantestbNFe(TbAssinantestbNFe tbAssinantestbNFe) {
        this.tbAssinantestbNFe = tbAssinantestbNFe;
    }

    @XmlTransient
    public Collection<TbNFetbNFeItens> getTbNFetbNFeItensCollection() {
        return tbNFetbNFeItensCollection;
    }

    public void setTbNFetbNFeItensCollection(Collection<TbNFetbNFeItens> tbNFetbNFeItensCollection) {
        this.tbNFetbNFeItensCollection = tbNFetbNFeItensCollection;
    }

    @XmlTransient
    public Collection<TbIpiDependencias> getTbIpiDependenciasCollection() {
        return tbIpiDependenciasCollection;
    }

    public void setTbIpiDependenciasCollection(Collection<TbIpiDependencias> tbIpiDependenciasCollection) {
        this.tbIpiDependenciasCollection = tbIpiDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbIcmsDependencias> getTbIcmsDependenciasCollection() {
        return tbIcmsDependenciasCollection;
    }

    public void setTbIcmsDependenciasCollection(Collection<TbIcmsDependencias> tbIcmsDependenciasCollection) {
        this.tbIcmsDependenciasCollection = tbIcmsDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbAssinantestbCTe> getTbAssinantestbCTeCollection() {
        return tbAssinantestbCTeCollection;
    }

    public void setTbAssinantestbCTeCollection(Collection<TbAssinantestbCTe> tbAssinantestbCTeCollection) {
        this.tbAssinantestbCTeCollection = tbAssinantestbCTeCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbAssinantes)) {
            return false;
        }
        TbAssinantes other = (TbAssinantes) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbAssinantes[ id=" + id + " ]";
    }
    
}
