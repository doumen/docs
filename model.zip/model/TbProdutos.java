/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbProdutos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbProdutos.findAll", query = "SELECT t FROM TbProdutos t"),
    @NamedQuery(name = "TbProdutos.findById", query = "SELECT t FROM TbProdutos t WHERE t.id = :id"),
    @NamedQuery(name = "TbProdutos.findByCodigo", query = "SELECT t FROM TbProdutos t WHERE t.codigo = :codigo"),
    @NamedQuery(name = "TbProdutos.findByCodigoBarras", query = "SELECT t FROM TbProdutos t WHERE t.codigoBarras = :codigoBarras"),
    @NamedQuery(name = "TbProdutos.findByCodigoBarrasTributavel", query = "SELECT t FROM TbProdutos t WHERE t.codigoBarrasTributavel = :codigoBarrasTributavel"),
    @NamedQuery(name = "TbProdutos.findByTipoProduto", query = "SELECT t FROM TbProdutos t WHERE t.tipoProduto = :tipoProduto"),
    @NamedQuery(name = "TbProdutos.findByDescricaoAssinante", query = "SELECT t FROM TbProdutos t WHERE t.descricaoAssinante = :descricaoAssinante"),
    @NamedQuery(name = "TbProdutos.findByDescricaoFornecedor", query = "SELECT t FROM TbProdutos t WHERE t.descricaoFornecedor = :descricaoFornecedor"),
    @NamedQuery(name = "TbProdutos.findByNcm", query = "SELECT t FROM TbProdutos t WHERE t.ncm = :ncm"),
    @NamedQuery(name = "TbProdutos.findByNcmEx", query = "SELECT t FROM TbProdutos t WHERE t.ncmEx = :ncmEx"),
    @NamedQuery(name = "TbProdutos.findByUnidadeMedidaTributavel", query = "SELECT t FROM TbProdutos t WHERE t.unidadeMedidaTributavel = :unidadeMedidaTributavel"),
    @NamedQuery(name = "TbProdutos.findByDataInclusao", query = "SELECT t FROM TbProdutos t WHERE t.dataInclusao = :dataInclusao")})
public class TbProdutos implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Codigo")
    private String codigo;
    @Column(name = "CodigoBarras")
    private Integer codigoBarras;
    @Column(name = "CodigoBarrasTributavel")
    private Integer codigoBarrasTributavel;
    @Basic(optional = false)
    @NotNull
    @Column(name = "TipoProduto")
    private Character tipoProduto;
    @Size(max = 120)
    @Column(name = "DescricaoAssinante")
    private String descricaoAssinante;
    @Size(max = 120)
    @Column(name = "DescricaoFornecedor")
    private String descricaoFornecedor;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Ncm")
    private int ncm;
    @Column(name = "NcmEx")
    private Integer ncmEx;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "UnidadeMedidaTributavel")
    private String unidadeMedidaTributavel;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbProdutoId")
    private Collection<TbPisDependencias> tbPisDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbProdutoId")
    private Collection<TbCofinsDependencias> tbCofinsDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbProdutoId")
    private Collection<TbProdutosDependencias> tbProdutosDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbProdutoId")
    private Collection<TbNFetbNFeItens> tbNFetbNFeItensCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbProdutoId")
    private Collection<TbIpiDependencias> tbIpiDependenciasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tbProdutoId")
    private Collection<TbIcmsDependencias> tbIcmsDependenciasCollection;

    public TbProdutos() {
    }

    public TbProdutos(Integer id) {
        this.id = id;
    }

    public TbProdutos(Integer id, String codigo, Character tipoProduto, int ncm, String unidadeMedidaTributavel, Date dataInclusao) {
        this.id = id;
        this.codigo = codigo;
        this.tipoProduto = tipoProduto;
        this.ncm = ncm;
        this.unidadeMedidaTributavel = unidadeMedidaTributavel;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Integer getCodigoBarras() {
        return codigoBarras;
    }

    public void setCodigoBarras(Integer codigoBarras) {
        this.codigoBarras = codigoBarras;
    }

    public Integer getCodigoBarrasTributavel() {
        return codigoBarrasTributavel;
    }

    public void setCodigoBarrasTributavel(Integer codigoBarrasTributavel) {
        this.codigoBarrasTributavel = codigoBarrasTributavel;
    }

    public Character getTipoProduto() {
        return tipoProduto;
    }

    public void setTipoProduto(Character tipoProduto) {
        this.tipoProduto = tipoProduto;
    }

    public String getDescricaoAssinante() {
        return descricaoAssinante;
    }

    public void setDescricaoAssinante(String descricaoAssinante) {
        this.descricaoAssinante = descricaoAssinante;
    }

    public String getDescricaoFornecedor() {
        return descricaoFornecedor;
    }

    public void setDescricaoFornecedor(String descricaoFornecedor) {
        this.descricaoFornecedor = descricaoFornecedor;
    }

    public int getNcm() {
        return ncm;
    }

    public void setNcm(int ncm) {
        this.ncm = ncm;
    }

    public Integer getNcmEx() {
        return ncmEx;
    }

    public void setNcmEx(Integer ncmEx) {
        this.ncmEx = ncmEx;
    }

    public String getUnidadeMedidaTributavel() {
        return unidadeMedidaTributavel;
    }

    public void setUnidadeMedidaTributavel(String unidadeMedidaTributavel) {
        this.unidadeMedidaTributavel = unidadeMedidaTributavel;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    @XmlTransient
    public Collection<TbPisDependencias> getTbPisDependenciasCollection() {
        return tbPisDependenciasCollection;
    }

    public void setTbPisDependenciasCollection(Collection<TbPisDependencias> tbPisDependenciasCollection) {
        this.tbPisDependenciasCollection = tbPisDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbCofinsDependencias> getTbCofinsDependenciasCollection() {
        return tbCofinsDependenciasCollection;
    }

    public void setTbCofinsDependenciasCollection(Collection<TbCofinsDependencias> tbCofinsDependenciasCollection) {
        this.tbCofinsDependenciasCollection = tbCofinsDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbProdutosDependencias> getTbProdutosDependenciasCollection() {
        return tbProdutosDependenciasCollection;
    }

    public void setTbProdutosDependenciasCollection(Collection<TbProdutosDependencias> tbProdutosDependenciasCollection) {
        this.tbProdutosDependenciasCollection = tbProdutosDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbNFetbNFeItens> getTbNFetbNFeItensCollection() {
        return tbNFetbNFeItensCollection;
    }

    public void setTbNFetbNFeItensCollection(Collection<TbNFetbNFeItens> tbNFetbNFeItensCollection) {
        this.tbNFetbNFeItensCollection = tbNFetbNFeItensCollection;
    }

    @XmlTransient
    public Collection<TbIpiDependencias> getTbIpiDependenciasCollection() {
        return tbIpiDependenciasCollection;
    }

    public void setTbIpiDependenciasCollection(Collection<TbIpiDependencias> tbIpiDependenciasCollection) {
        this.tbIpiDependenciasCollection = tbIpiDependenciasCollection;
    }

    @XmlTransient
    public Collection<TbIcmsDependencias> getTbIcmsDependenciasCollection() {
        return tbIcmsDependenciasCollection;
    }

    public void setTbIcmsDependenciasCollection(Collection<TbIcmsDependencias> tbIcmsDependenciasCollection) {
        this.tbIcmsDependenciasCollection = tbIcmsDependenciasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbProdutos)) {
            return false;
        }
        TbProdutos other = (TbProdutos) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbProdutos[ id=" + id + " ]";
    }
    
}
