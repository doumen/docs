/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbIpi_Dependencias")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbIpiDependencias.findAll", query = "SELECT t FROM TbIpiDependencias t"),
    @NamedQuery(name = "TbIpiDependencias.findById", query = "SELECT t FROM TbIpiDependencias t WHERE t.id = :id"),
    @NamedQuery(name = "TbIpiDependencias.findByDataInclusao", query = "SELECT t FROM TbIpiDependencias t WHERE t.dataInclusao = :dataInclusao")})
public class TbIpiDependencias implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @JoinColumn(name = "tbAssinantes_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbAssinantes tbAssinantesId;
    @JoinColumn(name = "tbCodigoEnquadramentoLegalIpi", referencedColumnName = "Id")
    @ManyToOne
    private TbCodigoEnquadramentoLegalIpi tbCodigoEnquadramentoLegalIpi;
    @JoinColumn(name = "tbCstIpi_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbCstIpi tbCstIpiId;
    @JoinColumn(name = "tbIpi_Id", referencedColumnName = "Id")
    @ManyToOne
    private TbIpi tbIpiId;
    @JoinColumn(name = "tbIpiSt_Id", referencedColumnName = "Id")
    @ManyToOne
    private TbIpiSt tbIpiStId;
    @JoinColumn(name = "tbNFe_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbAssinantestbNFe tbNFeId;
    @JoinColumn(name = "tbNFeArquivos_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbNFeArquivos tbNFeArquivosId;
    @JoinColumn(name = "tbNFeItens_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbNFeItens tbNFeItensId;
    @JoinColumn(name = "tbProduto_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbProdutos tbProdutoId;
    @JoinColumn(name = "tbTipi_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbTipi tbTipiId;

    public TbIpiDependencias() {
    }

    public TbIpiDependencias(Integer id) {
        this.id = id;
    }

    public TbIpiDependencias(Integer id, Date dataInclusao) {
        this.id = id;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public TbAssinantes getTbAssinantesId() {
        return tbAssinantesId;
    }

    public void setTbAssinantesId(TbAssinantes tbAssinantesId) {
        this.tbAssinantesId = tbAssinantesId;
    }

    public TbCodigoEnquadramentoLegalIpi getTbCodigoEnquadramentoLegalIpi() {
        return tbCodigoEnquadramentoLegalIpi;
    }

    public void setTbCodigoEnquadramentoLegalIpi(TbCodigoEnquadramentoLegalIpi tbCodigoEnquadramentoLegalIpi) {
        this.tbCodigoEnquadramentoLegalIpi = tbCodigoEnquadramentoLegalIpi;
    }

    public TbCstIpi getTbCstIpiId() {
        return tbCstIpiId;
    }

    public void setTbCstIpiId(TbCstIpi tbCstIpiId) {
        this.tbCstIpiId = tbCstIpiId;
    }

    public TbIpi getTbIpiId() {
        return tbIpiId;
    }

    public void setTbIpiId(TbIpi tbIpiId) {
        this.tbIpiId = tbIpiId;
    }

    public TbIpiSt getTbIpiStId() {
        return tbIpiStId;
    }

    public void setTbIpiStId(TbIpiSt tbIpiStId) {
        this.tbIpiStId = tbIpiStId;
    }

    public TbAssinantestbNFe getTbNFeId() {
        return tbNFeId;
    }

    public void setTbNFeId(TbAssinantestbNFe tbNFeId) {
        this.tbNFeId = tbNFeId;
    }

    public TbNFeArquivos getTbNFeArquivosId() {
        return tbNFeArquivosId;
    }

    public void setTbNFeArquivosId(TbNFeArquivos tbNFeArquivosId) {
        this.tbNFeArquivosId = tbNFeArquivosId;
    }

    public TbNFeItens getTbNFeItensId() {
        return tbNFeItensId;
    }

    public void setTbNFeItensId(TbNFeItens tbNFeItensId) {
        this.tbNFeItensId = tbNFeItensId;
    }

    public TbProdutos getTbProdutoId() {
        return tbProdutoId;
    }

    public void setTbProdutoId(TbProdutos tbProdutoId) {
        this.tbProdutoId = tbProdutoId;
    }

    public TbTipi getTbTipiId() {
        return tbTipiId;
    }

    public void setTbTipiId(TbTipi tbTipiId) {
        this.tbTipiId = tbTipiId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbIpiDependencias)) {
            return false;
        }
        TbIpiDependencias other = (TbIpiDependencias) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbIpiDependencias[ id=" + id + " ]";
    }
    
}
