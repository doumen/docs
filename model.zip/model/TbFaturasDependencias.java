/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author desenv
 */
@Entity
@Table(name = "tbFaturas_Dependencias")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbFaturasDependencias.findAll", query = "SELECT t FROM TbFaturasDependencias t"),
    @NamedQuery(name = "TbFaturasDependencias.findById", query = "SELECT t FROM TbFaturasDependencias t WHERE t.id = :id"),
    @NamedQuery(name = "TbFaturasDependencias.findByDataInclusao", query = "SELECT t FROM TbFaturasDependencias t WHERE t.dataInclusao = :dataInclusao")})
public class TbFaturasDependencias implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DataInclusao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInclusao;
    @JoinColumn(name = "tbAssinantes_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbAssinantes tbAssinantesId;
    @JoinColumn(name = "tbFaturasConfiguracoes_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbFaturasConfiguracoes tbFaturasConfiguracoesId;
    @JoinColumn(name = "tbFaturas_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbFaturas tbFaturasId;
    @JoinColumn(name = "tbNFe_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbNFe tbNFeId;
    @JoinColumn(name = "tbNFeArquivos_Id", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private TbNFeArquivos tbNFeArquivosId;

    public TbFaturasDependencias() {
    }

    public TbFaturasDependencias(Integer id) {
        this.id = id;
    }

    public TbFaturasDependencias(Integer id, Date dataInclusao) {
        this.id = id;
        this.dataInclusao = dataInclusao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public TbAssinantes getTbAssinantesId() {
        return tbAssinantesId;
    }

    public void setTbAssinantesId(TbAssinantes tbAssinantesId) {
        this.tbAssinantesId = tbAssinantesId;
    }

    public TbFaturasConfiguracoes getTbFaturasConfiguracoesId() {
        return tbFaturasConfiguracoesId;
    }

    public void setTbFaturasConfiguracoesId(TbFaturasConfiguracoes tbFaturasConfiguracoesId) {
        this.tbFaturasConfiguracoesId = tbFaturasConfiguracoesId;
    }

    public TbFaturas getTbFaturasId() {
        return tbFaturasId;
    }

    public void setTbFaturasId(TbFaturas tbFaturasId) {
        this.tbFaturasId = tbFaturasId;
    }

    public TbNFe getTbNFeId() {
        return tbNFeId;
    }

    public void setTbNFeId(TbNFe tbNFeId) {
        this.tbNFeId = tbNFeId;
    }

    public TbNFeArquivos getTbNFeArquivosId() {
        return tbNFeArquivosId;
    }

    public void setTbNFeArquivosId(TbNFeArquivos tbNFeArquivosId) {
        this.tbNFeArquivosId = tbNFeArquivosId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbFaturasDependencias)) {
            return false;
        }
        TbFaturasDependencias other = (TbFaturasDependencias) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TbFaturasDependencias[ id=" + id + " ]";
    }
    
}
